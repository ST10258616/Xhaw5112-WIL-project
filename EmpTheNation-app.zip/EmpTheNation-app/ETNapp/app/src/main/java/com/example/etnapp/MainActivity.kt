package com.example.etnapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    private lateinit var Button : sixMonthBtn
    private lateinit var Button : sixWeekBtn

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sixMonthBtn = findViewById<Button>(R.id.sixMonthBtn)
        sixWeekBtn = findViewById<Button>(R.id.sixWeekBtn)

        sixMonthBtn.setOnClickListener {
            val intent = Intent(this, SixMonthCoursesActivity::class.java)
            startActivity(intent)
        }

        sixWeekBtn.setOnClickListener {
            val intent = Intent(this, SixWeekCoursesActivity::class.java)
            startActivity(intent)
        }

    }
}